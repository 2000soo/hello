package com.human.cds.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.http.ResponseEntity;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/member")
public class MemberController {

    // 로그인 페이지
    @GetMapping("/login.do")
    public String login() {
        return "member/login"; // login.jsp
    }

    // 회원가입 페이지
    @GetMapping("/signup.do")
    public String register() {
        return "member/signup"; // signup.jsp
    }

    // 아이디 찾기 페이지
    @GetMapping("/idFind.do")
    public String idFind() {
        return "member/idFind"; // idFind.jsp
    }

    // 비밀번호 찾기 페이지
    @GetMapping("/passwordFind.do")
    public String passwordFind() {
        return "member/passwordFind"; // passwordFind.jsp
    }

    // 회원가입 처리
    @PostMapping("/signup.do")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> registerMember(
        @RequestParam("name") String name,
        @RequestParam("phone") String phone,
        @RequestParam("username") String username,
        @RequestParam("password") String password,
        @RequestParam("email") String email,
        @RequestParam("gender") String gender) {
        
        Map<String, Object> response = new HashMap<>();
        
        // 비밀번호 암호화 및 사용자 저장 로직 추가
        // 예: userService.registerUser(...)

        response.put("success", true);
        return ResponseEntity.ok(response);
    }

    // 로그인 처리
    @PostMapping("/login.do")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> loginMember(
        @RequestParam("username") String username,
        @RequestParam("password") String password) {
        
        Map<String, Object> response = new HashMap<>();
        
        // 로그인 로직 추가
        // 예: userService.loginUser(...)

        response.put("success", true);
        return ResponseEntity.ok(response);
    }

    // 비밀번호 찾기 처리
    @PostMapping("/passwordFind")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> findPassword(
        @RequestParam("username") String username,
        @RequestParam("name") String name,
        @RequestParam("email") String email) {
        
        Map<String, Object> response = new HashMap<>();
        
        // 비밀번호 찾기 로직 추가
        // 예: userService.findPassword(...)

        response.put("success", true);
        return ResponseEntity.ok(response);
    }

    // 아이디 찾기 처리
    @PostMapping("/idFind")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> findId(
        @RequestParam("name") String name,
        @RequestParam("email") String email) {
        
        Map<String, Object> response = new HashMap<>();
        
        // 아이디 찾기 로직 추가
        // 예: userService.findId(...)

        response.put("success", true);
        // 예: response.put("id", foundId);
        return ResponseEntity.ok(response);
    }
}
