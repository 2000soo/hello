package com.human.cds.vo;

import lombok.Data;

@Data
public class RegionCourseDTO {
	private String content_id;  // content_id 필드 추가
    private String firstImage;
    private String title;
    private String areaCode;
}