package com.human.cds.vo;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class MemberVO {

	    private int id; // 회원 ID
	    private String memberId; // 아이디
	    private String password; // 비밀번호
	    private Date birthDate; // 생년월일
	    private String phone; // 전화번호
	    private String name; // 이름
	    private String email; // 이메일
	    private String gender; // 성별
	    private boolean marketingConsent; // 마케팅 수신 동의 여부
	    private String profileImage; // 프로필 이미지
	    private boolean withdrawalRequest; // 탈퇴 요청 여부
	    private String membershipLevel; // 회원 등급
	    private Date createdAt; // 가입일
		public String getMemberId() {
			// TODO Auto-generated method stub
			return null;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public Date getBirthDate() {
			return birthDate;
		}
		public void setBirthDate(Date birthDate) {
			this.birthDate = birthDate;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public boolean isMarketingConsent() {
			return marketingConsent;
		}
		public void setMarketingConsent(boolean marketingConsent) {
			this.marketingConsent = marketingConsent;
		}
		public String getProfileImage() {
			return profileImage;
		}
		public void setProfileImage(String profileImage) {
			this.profileImage = profileImage;
		}
		public boolean isWithdrawalRequest() {
			return withdrawalRequest;
		}
		public void setWithdrawalRequest(boolean withdrawalRequest) {
			this.withdrawalRequest = withdrawalRequest;
		}
		public String getMembershipLevel() {
			return membershipLevel;
		}
		public void setMembershipLevel(String membershipLevel) {
			this.membershipLevel = membershipLevel;
		}
		public Date getCreatedAt() {
			return createdAt;
		}
		public void setCreatedAt(Date createdAt) {
			this.createdAt = createdAt;
		}
		public void setMemberId(String memberId) {
			this.memberId = memberId;
		}
		
		
	}
	

