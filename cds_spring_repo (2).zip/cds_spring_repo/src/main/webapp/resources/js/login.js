$(document).ready(function() {
    $('#loginForm').on('submit', function(e) {
        e.preventDefault(); // Prevent the default form submission

        $.ajax({
            type: 'POST',
            url: '/member/login.do', // Your endpoint
            data: $(this).serialize(), // Serialize form data
            success: function(response) {
                if (response.success) {
                    alert('로그인 성공');
                    window.location.href = '/'; // Redirect to home or desired page
                } else {
                    alert('로그인 실패: ' + response.message);
                }
            },
            error: function() {
                alert('서버 오류. 다시 시도해주세요.');
            }
        });
    });
});
