package com.human.cds.model;

public class Member {
    private int id; // 회원 ID
    private String memberId; // 회원 ID (로그인용)
    private String password; // 비밀번호
    private String birthDate; // 생년월일
    private String phone; // 전화번호
    private String name; // 이름
    private String email; // 이메일
    private String gender; // 성별 (M: 남성, F: 여성)
    private boolean marketingConsent; // 마케팅 동의 여부
    private String profileImage; // 프로필 이미지
    private boolean withdrawalRequest; // 탈퇴 신청 여부
    private String membershipLevel; // 회원 등급
    private String createdAt; // 가입일

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isMarketingConsent() {
        return marketingConsent;
    }

    public void setMarketingConsent(boolean marketingConsent) {
        this.marketingConsent = marketingConsent;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public boolean isWithdrawalRequest() {
        return withdrawalRequest;
    }

    public void setWithdrawalRequest(boolean withdrawalRequest) {
        this.withdrawalRequest = withdrawalRequest;
    }

    public String getMembershipLevel() {
        return membershipLevel;
    }

    public void setMembershipLevel(String membershipLevel) {
        this.membershipLevel = membershipLevel;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
