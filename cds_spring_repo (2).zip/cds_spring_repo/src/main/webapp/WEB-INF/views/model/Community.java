package com.human.cds.model;

public class Community {
    private int id;           // 게시물 ID
    private int memberId;     // 회원 ID
    private String title;     // 게시물 제목
    private String content;   // 게시물 내용
    private String location;  // 게시물 위치

    // 기본 생성자
    public Community() {}

    // 모든 필드를 포함하는 생성자
    public Community(int id, int memberId, String title, String content, String location) {
        this.id = id;
        this.memberId = memberId;
        this.title = title;
        this.content = content;
        this.location = location;
    }

    // Getter 및 Setter 메서드
    public int getId() {
        return id; // 게시물 ID 반환
    }

    public void setId(int id) {
        this.id = id; // 게시물 ID 설정
    }

    public int getMemberId() {
        return memberId; // 회원 ID 반환
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId; // 회원 ID 설정
    }

    public String getTitle() {
        return title; // 게시물 제목 반환
    }

    public void setTitle(String title) {
        this.title = title; // 게시물 제목 설정
    }

    public String getContent() {
        return content; // 게시물 내용 반환
    }

    public void setContent(String content) {
        this.content = content; // 게시물 내용 설정
    }

    public String getLocation() {
        return location; // 게시물 위치 반환
    }

    public void setLocation(String location) {
        this.location = location; // 게시물 위치 설정
    }
}
